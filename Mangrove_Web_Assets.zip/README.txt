ASET WEBSITE BAKAU - PAKET ILUSTRASI

Style: vektor kartun hijau cerah, outline tegas, shading berlapis.
Gambar berbasis ilustrasi dan dipisah dari satu lembar aset.

BACKGROUNDS
- hero-mangrove-coast.png: latar hero landscape, cocok dengan teks overlay
- section-soft-green.png: latar section informatif ringan
- section-deep-green.png: latar CTA / banner ajakan
- section-ocean-blue.png: latar statistik / air / pesisir

ILLUSTRATIONS (latar luar transparan)
- mangrove-seedling.png: dampak dan bibit bakau
- mangrove-forest.png: ekosistem pesisir
- community-planting.png: ajakan menanam
- forest-monitoring-drone.png: monitoring / teknologi
- mangrove-protection.png: perlindungan ekosistem
- mangrove-restoration.png: restorasi dan keberlanjutan

ICONS
- seedling, forest, water, progress, community, education

DECORATIONS
- forest-bushes, rock-and-plants, sea-wave

Catatan: aset hasil potongan lembar ilustrasi, bukan SVG vektor.
